﻿#Requires -Version 5.1

$ErrorActionPreference = 'Stop'
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $Utf8NoBom
$OutputEncoding = $Utf8NoBom

$BeikeExe = Join-Path $env:LOCALAPPDATA 'beike\beike.exe'
$AuthConsoleUrl = 'https://building.ke.com/console'
$DefaultCityFile = Join-Path $env:USERPROFILE '.beike\DEFAULT_QUERY_CITY'

function Write-Line {
    Write-Host ('=' * 60)
}

function Stop-Query([string]$Message, [int]$Code = 1) {
    Write-Host ''
    Write-Host $Message -ForegroundColor Red
    exit $Code
}

Write-Line
Write-Host '贝壳房源 ID 抓取器｜Windows'
Write-Line
Write-Host ''

if (-not (Test-Path $BeikeExe)) {
    Stop-Query '还没有安装贝壳工具，请先双击“1-一键安装.cmd”。' 1
}

$doctorText = (& $BeikeExe doctor --pretty 2>&1 | Out-String)
if ($LASTEXITCODE -ne 0 -or $doctorText -notmatch 'Key 有效') {
    Write-Host '当前授权缺失或已经失效。我已打开“凭证与安全”页。'
    Write-Host '复制未标记“已失效”的 Key 后，重新运行一键安装。'
    Start-Process $AuthConsoleUrl
    exit 2
}

$defaultCity = ''
if (Test-Path $DefaultCityFile) {
    $defaultCity = (Get-Content -LiteralPath $DefaultCityFile -Encoding UTF8 | Select-Object -First 1).Trim()
}

if ($defaultCity) {
    $city = Read-Host "请输入城市，直接回车使用上次的：$defaultCity"
    if ([string]::IsNullOrWhiteSpace($city)) {
        $city = $defaultCity
    }
}
else {
    $city = Read-Host '请输入城市，例如 成都、东莞、北京'
}

if ([string]::IsNullOrWhiteSpace($city)) {
    Stop-Query '城市不能为空。贝壳官方查询必须同时提供城市和房源 ID。' 3
}

$defaultCityDir = Split-Path -Parent $DefaultCityFile
New-Item -ItemType Directory -Path $defaultCityDir -Force | Out-Null
Set-Content -LiteralPath $DefaultCityFile -Value $city -Encoding UTF8

Write-Host ''
Write-Host '请选择 ID 类型：'
Write-Host '  1. 二手房房源 ID（默认）'
Write-Host '  2. 新房楼盘/房源 ID'
Write-Host '  3. 小区/楼盘 ID'
$typeChoice = Read-Host '请输入 1、2 或 3，直接回车选 1'
if ([string]::IsNullOrWhiteSpace($typeChoice)) {
    $typeChoice = '1'
}

switch ($typeChoice) {
    '1' {
        $entityType = 'house'
        $entityLabel = '二手房房源'
    }
    '2' {
        $entityType = 'newhouse'
        $entityLabel = '新房楼盘-房源'
    }
    '3' {
        $entityType = 'resblock'
        $entityLabel = '小区-楼盘'
    }
    default {
        Stop-Query '类型选择无效。' 4
    }
}

Write-Host ''
$idsRaw = Read-Host '请粘贴房源 ID；多个 ID 可用空格或逗号分隔'
$ids = @($idsRaw -split '[\s,，]+' | Where-Object { $_ })
if ($ids.Count -eq 0) {
    Stop-Query '没有识别到房源 ID。' 5
}

$idArgs = New-Object System.Collections.Generic.List[string]
foreach ($entityId in $ids) {
    if ($entityId -notmatch '^[A-Za-z0-9_-]+$') {
        Stop-Query "ID 格式不正确：$entityId" 6
    }
    $idArgs.Add('--id')
    $idArgs.Add($entityId)
}

$desktopPath = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrWhiteSpace($desktopPath)) {
    $desktopPath = Join-Path $env:USERPROFILE 'Desktop'
}
$reportDir = Join-Path $desktopPath '贝壳房源抓取结果'
New-Item -ItemType Directory -Path $reportDir -Force | Out-Null

$invalidChars = [IO.Path]::GetInvalidFileNameChars()
$safeCity = -join ($city.ToCharArray() | ForEach-Object { if ($invalidChars -contains $_) { '-' } else { $_ } })
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$firstId = $ids[0]
$idSuffix = if ($ids.Count -gt 1) { "$firstId-等$($ids.Count)个" } else { $firstId }
$reportFile = Join-Path $reportDir "$safeCity-$entityLabel-$idSuffix-$timestamp.md"

Write-Host ''
Write-Host "正在抓取：$city｜$entityLabel｜$($ids.Count) 个 ID……"

$detailArgs = @('buy', 'detail', '-c', $city) + $idArgs.ToArray() + @('-t', $entityType, '--pretty')
$detailOutput = (& $BeikeExe @detailArgs 2>&1 | Out-String)
$detailExitCode = $LASTEXITCODE
if ($detailExitCode -ne 0 -or $detailOutput -match 'Invalid or missing Authorization|Key 无效|isError.{0,20}true') {
    Stop-Query '官方没有返回有效数据。请核对城市、ID、房源状态和授权。' 7
}

$materialOutput = ''
$materialOk = $false
if ($entityType -ne 'resblock') {
    $materialArgs = @('buy', 'material', '-c', $city) + $idArgs.ToArray() + @('-t', $entityType, '--pretty')
    $materialOutput = (& $BeikeExe @materialArgs 2>&1 | Out-String)
    if ($LASTEXITCODE -eq 0 -and $materialOutput -notmatch 'Invalid or missing Authorization|Key 无效|isError.{0,20}true') {
        $materialOk = $true
    }
}

$reportParts = New-Object System.Collections.Generic.List[string]
$reportParts.Add('# 贝壳房源抓取结果')
$reportParts.Add('')
$reportParts.Add("- 查询时间：$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
$reportParts.Add("- 城市：$city")
$reportParts.Add("- 类型：$entityLabel")
$reportParts.Add("- 房源 ID：$($ids -join ', ')")
$reportParts.Add('- 数据来源：贝壳官方 CLI / MCP')
$reportParts.Add('')
$reportParts.Add('> 本报告仅用于信息初筛。房源状态、价格、权属、抵押、学区和交易条件可能变化，交易前请再次向官方及经纪人核验。')
$reportParts.Add('')
$reportParts.Add('## 房源详情')
$reportParts.Add('')
$reportParts.Add($detailOutput.Trim())

if ($materialOk) {
    $reportParts.Add('')
    $reportParts.Add('## 图片、户型图与 VR 信息')
    $reportParts.Add('')
    $reportParts.Add($materialOutput.Trim())
}

try {
    $Utf8Bom = New-Object System.Text.UTF8Encoding($true)
    [IO.File]::WriteAllText($reportFile, ($reportParts -join [Environment]::NewLine), $Utf8Bom)
}
catch {
    Stop-Query '报告写入失败，请检查桌面目录是否可写。' 8
}

Write-Host ''
Write-Line
Write-Host '✓ 抓取完成' -ForegroundColor Green
Write-Host '报告已保存到：'
Write-Host $reportFile
Write-Line
Start-Process -FilePath $reportFile
exit 0
