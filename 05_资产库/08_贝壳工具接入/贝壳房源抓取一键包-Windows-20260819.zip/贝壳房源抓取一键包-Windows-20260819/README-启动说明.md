# 贝壳房源抓取一键包（Windows）

适用系统：Windows 10/11 x64。

安装完成后，输入城市和贝壳房源 ID，即可抓取二手房、新房或小区详情，并自动保存成报告。

## 第一次安装

1. 完整解压 ZIP，不要直接在压缩包预览窗口内运行。
2. 双击 `1-一键安装.cmd`。
3. 安装器会校验并安装包内 7 个官方贝壳 Skills。
4. 安装器会优先使用包内 Windows x64 CLI 0.2.24，并核对官方 SHA-256；包内文件缺失时才从贝壳官方 GitHub Release 下载备用副本。
5. 浏览器打开后，用使用者自己的贝壳 C 端账号登录。
6. 进入“凭证与安全”，复制没有“已失效”标签的 Bearer Key。
7. 回到安装窗口按回车，安装器会从 Windows 剪贴板安全保存授权，不会显示 Key。
8. 看到“安装和授权已经完成”后，完全退出并重新打开 Codex。

不需要管理员权限。CLI 安装到：

`%LOCALAPPDATA%\beike\beike.exe`

Skills 安装到：

`%USERPROFILE%\.codex\skills\`

## 日常抓取

双击 `2-输入ID抓取房源.cmd`，按提示填写：

- 城市：第一次必须填写，之后会记住上次城市。
- 类型：二手房、新房或小区。
- 房源 ID：支持一个或多个，用空格、英文逗号或中文逗号分隔。

报告默认保存在：

`桌面\贝壳房源抓取结果\`

抓取成功后会自动打开报告。

## 为什么需要城市

贝壳官方详情接口要求“城市 + 房源 ID”同时提供。启动器会记住上次城市，同一城市连续抓取时，后续只需回车确认城市，再粘贴 ID。

## 检查状态

双击 `3-检查工具状态.cmd`。只有同时显示下面两项，才表示真的可以使用：

- API 可达
- Key 有效

网页显示登录成功或电脑里存在 Key 文件，都不能代替官方接口校验。

## Windows 安全提示

如果 Windows Defender SmartScreen 提示“Windows 已保护你的电脑”，请先确认 ZIP 是你收到的这一份，再选择“更多信息”→“仍要运行”。不要从陌生渠道下载修改版。

本包通过 PowerShell 的当前进程级 `ExecutionPolicy Bypass` 启动内部脚本，不修改电脑的全局执行策略。

## 安全说明

- 本包没有制作人的账号、Bearer Key、Cookie 或个人授权。
- 每位使用者必须登录自己的贝壳账号。
- 不要把 Key 发到群聊、邮件、网盘或公开代码仓库。
- 授权完成后，建议复制一段普通文字覆盖剪贴板中的 Key。

## 常见问题

### CLI 下载失败

正常情况下不需要下载 CLI，本包已内置官方 Windows x64 CLI。只有包内 CLI 被删除或不完整时，安装器才会从官方 GitHub Release 下载备用副本。安装器会核对 SHA-256，校验不一致不会显示安装成功。

### Key 无效或已过期

打开 [贝壳凭证管理页](https://building.ke.com/console)，复制没有“已失效”标签的 Key，再运行一键安装器。不要复制旧授权弹窗中的失效命令。

### 抓取失败

先核对城市与 ID 是否对应，再检查房源是否下架，最后运行状态检查。

### Codex 没有识别 Skills

安装后完全退出 Codex，再重新打开。

## 数据边界

报告仅用于信息初筛。挂牌状态、价格、权属、抵押、税费、贷款、学区和周边信息均可能变化，交易前应进行产权查档、官方学区核验、银行审批和实地核验。

请合理使用官方能力，避免高频、批量或违反平台规则的采集。

## 官方来源

- [贝壳 AI Platform](https://github.com/LianjiaTech/beike-ai-platform)
- [官方 Windows 安装脚本](https://github.com/LianjiaTech/beike-ai-platform/blob/master/cli/releases/install.ps1)
- [官方 CLI 版本清单](https://raw.githubusercontent.com/LianjiaTech/beike-ai-platform/master/cli/releases/manifest.json)
- [官方授权说明](https://github.com/LianjiaTech/beike-ai-platform/blob/master/docs/authentication.md)
- [凭证与安全](https://building.ke.com/console)

资源包版本：1.1.0  
制作日期：2026-08-19  
验证时官方 CLI 最新版本：0.2.24
