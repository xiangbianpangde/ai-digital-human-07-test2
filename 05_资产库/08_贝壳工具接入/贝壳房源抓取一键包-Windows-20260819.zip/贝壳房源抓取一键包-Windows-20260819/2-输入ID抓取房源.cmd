@echo off
chcp 65001 >nul
setlocal
set "PS_SCRIPT=%~dp0scripts\query.ps1"
if not exist "%PS_SCRIPT%" (
  echo Query script is missing.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" echo Query did not complete. See the message above.
pause
exit /b %EXIT_CODE%
