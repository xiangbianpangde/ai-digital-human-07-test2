﻿#Requires -Version 5.1

$ErrorActionPreference = 'Continue'
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $Utf8NoBom
$OutputEncoding = $Utf8NoBom

$BeikeExe = Join-Path $env:LOCALAPPDATA 'beike\beike.exe'
$CodexSkillsDir = Join-Path $env:USERPROFILE '.codex\skills'
$ExpectedSkills = @('beike-buy', 'beike-market', 'beike-policy', 'beike-rent', 'beike-school', 'beike-sell', 'beike-decor')

Write-Host ('=' * 60)
Write-Host '贝壳房源抓取工具｜Windows 状态检查'
Write-Host ('=' * 60)
Write-Host ''

$exitCode = 0
if (Test-Path $BeikeExe) {
    $version = (& $BeikeExe --version 2>$null | Select-Object -First 1)
    Write-Host "✓ CLI：$version"
}
else {
    Write-Host '✗ CLI 尚未安装，请双击“1-一键安装.cmd”。' -ForegroundColor Red
    $exitCode = 1
}

$missingSkills = @()
foreach ($skillName in $ExpectedSkills) {
    if (-not (Test-Path (Join-Path $CodexSkillsDir "$skillName\SKILL.md"))) {
        $missingSkills += $skillName
    }
}

if ($missingSkills.Count -eq 0) {
    Write-Host '✓ Codex Skills：7/7 已安装'
}
else {
    Write-Host "✗ 缺少 Skills：$($missingSkills -join ', ')" -ForegroundColor Red
    $exitCode = 2
}

Write-Host ''
if (Test-Path $BeikeExe) {
    & $BeikeExe doctor --pretty
    if ($LASTEXITCODE -ne 0) {
        $exitCode = 3
    }
}

Write-Host ''
Write-Host '判断标准：必须同时显示 API 可达、Key 有效，才可以正常抓取。'
exit $exitCode
