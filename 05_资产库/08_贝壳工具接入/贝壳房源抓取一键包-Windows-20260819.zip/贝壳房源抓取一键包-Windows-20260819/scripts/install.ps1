﻿#Requires -Version 5.1

[CmdletBinding()]
param(
    [switch]$TestMode
)

$ErrorActionPreference = 'Stop'
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $Utf8NoBom
$OutputEncoding = $Utf8NoBom
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$PackageRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$PayloadRoot = Join-Path $PackageRoot 'payload'
$PayloadSkills = Join-Path $PayloadRoot 'skills'
$PayloadChecksums = Join-Path $PackageRoot 'PAYLOAD-SHA256.json'
$CodexSkillsDir = Join-Path $env:USERPROFILE '.codex\skills'
$InstallDir = Join-Path $env:LOCALAPPDATA 'beike'
$BeikeExe = Join-Path $InstallDir 'beike.exe'
$AuthConsoleUrl = 'https://building.ke.com/console'

$CliVersion = '0.2.24'
$CliUrl = 'https://github.com/LianjiaTech/beike-ai-platform/releases/download/v0.2.24/beike-win32-x64-0.2.24.tar.gz'
$CliArchiveSha256 = 'a56e2d0f6a78bebdc44dafcbc7d2e67cfa55a89639e63b9a6d319601176fabaf'
$BundledCliArchive = Join-Path $PayloadRoot 'bin\beike-win32-x64-0.2.24.tar.gz'

$ExpectedSkills = @(
    'beike-buy',
    'beike-market',
    'beike-policy',
    'beike-rent',
    'beike-school',
    'beike-sell',
    'beike-decor'
)

function Write-Line {
    Write-Host ('=' * 60)
}

function Stop-Install([string]$Message, [int]$Code = 1) {
    Write-Host ''
    Write-Host "安装没有完成：$Message" -ForegroundColor Red
    exit $Code
}

function Test-BeikeDoctor {
    if (-not (Test-Path $BeikeExe)) {
        return $false
    }
    try {
        $doctorText = (& $BeikeExe doctor --pretty 2>&1 | Out-String)
        return ($LASTEXITCODE -eq 0 -and $doctorText -match 'Key 有效')
    }
    catch {
        return $false
    }
}

function Get-ClipboardTextSafe {
    $getClipboardCommand = Get-Command Get-Clipboard -ErrorAction SilentlyContinue
    if ($getClipboardCommand) {
        return (Get-Clipboard -Raw -ErrorAction Stop)
    }

    Add-Type -AssemblyName System.Windows.Forms
    return [System.Windows.Forms.Clipboard]::GetText()
}

function Get-KeyFromClipboard {
    $rawClipboardText = Get-ClipboardTextSafe
    if ([string]::IsNullOrWhiteSpace($rawClipboardText)) {
        return $null
    }
    $clipboardText = $rawClipboardText.Trim()
    if ($clipboardText -match '^beike\s+auth\s+([A-Za-z0-9_-]{20,200})\s+--save$') {
        return $Matches[1]
    }
    if ($clipboardText -match '^[A-Za-z0-9_-]{20,200}$') {
        return $clipboardText
    }
    return $null
}

Write-Line
Write-Host '贝壳房源抓取工具｜Windows 一键安装'
Write-Host '资源包版本：1.1.0'
Write-Line
Write-Host ''

if (-not [Environment]::Is64BitOperatingSystem) {
    Stop-Install '当前组件仅支持 Windows 10/11 x64。'
}

if (-not (Test-Path $PayloadChecksums)) {
    Stop-Install '缺少包内完整性清单 PAYLOAD-SHA256.json。'
}

Write-Host '[1/4] 正在校验包内官方 CLI 和 7 个贝壳 Skills……'
$checksumData = Get-Content -LiteralPath $PayloadChecksums -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($fileEntry in $checksumData.files) {
    $fullPath = Join-Path $PackageRoot $fileEntry.path
    if (-not (Test-Path -LiteralPath $fullPath)) {
        Stop-Install "包内文件缺失：$($fileEntry.path)"
    }
    $actualHash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $fileEntry.sha256.ToLowerInvariant()) {
        Stop-Install "包内文件校验失败：$($fileEntry.path)"
    }
}

Write-Host '[2/4] 正在安装 7 个官方贝壳 Skills 到 Codex……'
New-Item -ItemType Directory -Path $CodexSkillsDir -Force | Out-Null
foreach ($skillName in $ExpectedSkills) {
    $sourceDir = Join-Path $PayloadSkills $skillName
    $destinationDir = Join-Path $CodexSkillsDir $skillName
    if (-not (Test-Path (Join-Path $sourceDir 'SKILL.md'))) {
        Stop-Install "缺少 $skillName。"
    }
    New-Item -ItemType Directory -Path $destinationDir -Force | Out-Null
    Copy-Item -Path (Join-Path $sourceDir '*') -Destination $destinationDir -Recurse -Force
}

Write-Host '[3/4] 正在安装贝壳官方 Windows CLI……'
$needsCliInstall = $true
if (Test-Path $BeikeExe) {
    try {
        $existingVersion = (& $BeikeExe --version 2>$null | Select-Object -First 1)
        if ($existingVersion -match [regex]::Escape($CliVersion)) {
            $needsCliInstall = $false
            Write-Host "✓ CLI 已是资源包验证版本：$existingVersion"
        }
    }
    catch {
        $needsCliInstall = $true
    }
}

if ($needsCliInstall) {
    $tempRoot = Join-Path $env:TEMP ('beike-win-package-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
    try {
        $archivePath = Join-Path $tempRoot 'beike-windows-x64.tar.gz'
        $downloaded = $false

        if (Test-Path -LiteralPath $BundledCliArchive) {
            Copy-Item -LiteralPath $BundledCliArchive -Destination $archivePath -Force
            $downloaded = $true
            Write-Host '✓ 正在使用包内已校验的官方 Windows CLI，无需下载。'
        }
        else {
            Write-Host '包内 CLI 不存在，正在从贝壳官方 GitHub Release 下载备用副本……'
            try {
                Invoke-WebRequest -Uri $CliUrl -OutFile $archivePath -UseBasicParsing -TimeoutSec 300
                $downloaded = $true
            }
            catch {
                $curlCommand = Get-Command curl.exe -ErrorAction SilentlyContinue
                if ($curlCommand) {
                    & curl.exe -fL --retry 5 --retry-delay 2 --connect-timeout 30 --max-time 600 -o $archivePath $CliUrl
                    if ($LASTEXITCODE -eq 0 -and (Test-Path $archivePath)) {
                        $downloaded = $true
                    }
                }
            }
        }

        if (-not $downloaded -or -not (Test-Path $archivePath)) {
            Stop-Install '无法从贝壳官方 GitHub Release 下载 Windows CLI。请检查网络后重试。' 21
        }

        if ((Get-Item $archivePath).Length -lt 1024) {
            Stop-Install 'CLI 下载文件过小，可能没有完整下载。' 22
        }

        $archiveHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($archiveHash -ne $CliArchiveSha256) {
            Stop-Install 'CLI 官方 SHA-256 校验失败，已停止安装。' 23
        }

        $tarCommand = Get-Command tar.exe -ErrorAction SilentlyContinue
        if (-not $tarCommand) {
            Stop-Install '系统缺少 tar.exe；需要 Windows 10 1803 或更高版本。' 24
        }

        $extractDir = Join-Path $tempRoot 'extract'
        New-Item -ItemType Directory -Path $extractDir -Force | Out-Null
        & tar.exe -xzf $archivePath -C $extractDir
        if ($LASTEXITCODE -ne 0) {
            Stop-Install 'CLI 解压失败。' 25
        }

        $downloadedExe = Get-ChildItem -Path $extractDir -Filter 'beike.exe' -Recurse | Select-Object -First 1
        if (-not $downloadedExe) {
            Stop-Install '压缩包中没有找到 beike.exe。' 26
        }

        New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
        Copy-Item -LiteralPath $downloadedExe.FullName -Destination $BeikeExe -Force
    }
    finally {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

$userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$pathParts = @($userPath -split ';' | Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') })
if ($pathParts -notcontains $InstallDir.TrimEnd('\')) {
    $newUserPath = if ([string]::IsNullOrWhiteSpace($userPath)) { $InstallDir } else { $userPath.TrimEnd(';') + ';' + $InstallDir }
    [Environment]::SetEnvironmentVariable('Path', $newUserPath, 'User')
}
$env:Path = $InstallDir + ';' + $env:Path

if (-not (Test-Path $BeikeExe)) {
    Stop-Install '安装完成后仍未找到 beike.exe。' 27
}

try {
    & $BeikeExe auth --register --pretty 2>$null | Out-Null
}
catch {
    # 手工复制 Key 的授权方式仍可继续使用。
}

if ($TestMode) {
    Write-Host '✓ 测试模式：CLI 与 7 个 Skills 安装完成，未进入账号授权。'
    exit 0
}

Write-Host '[4/4] 正在检查个人账号授权……'
if (-not (Test-BeikeDoctor)) {
    Write-Host ''
    Write-Host '接下来请使用你自己的贝壳 C 端账号授权：'
    Write-Host '  1. 浏览器登录贝壳账号。'
    Write-Host '  2. 进入“凭证与安全”。'
    Write-Host '  3. 找到没有“已失效”标签的 Bearer Key。'
    Write-Host '  4. 点击这一行的“复制”，不要复制旧弹窗里的命令。'
    Write-Host ''
    Start-Process $AuthConsoleUrl

    $authSuccess = $false
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        Read-Host '复制有效 Key 后，回到这里按回车继续'
        $keyValue = Get-KeyFromClipboard
        if (-not $keyValue) {
            Write-Host '剪贴板里的内容不像完整 Key，请重新复制。' -ForegroundColor Yellow
            continue
        }

        try {
            & $BeikeExe auth $keyValue --save --pretty 2>$null | Out-Null
        }
        finally {
            $keyValue = $null
        }

        if (Test-BeikeDoctor) {
            $authSuccess = $true
            break
        }
        Write-Host '这份 Key 没有通过官方校验，请复制未标记“已失效”的 Key。' -ForegroundColor Yellow
    }

    if (-not $authSuccess) {
        Stop-Install '账号授权仍未通过官方校验。' 28
    }
}

$finalVersion = (& $BeikeExe --version 2>$null | Select-Object -First 1)
Write-Host ''
Write-Line
Write-Host '✓ Windows 安装和授权已经完成' -ForegroundColor Green
Write-Host "✓ $finalVersion"
Write-Host '✓ 7 个官方贝壳 Skills 已安装到 Codex'
Write-Host '✓ API 和 Key 官方校验已通过'
Write-Host ''
Write-Host '下一步：双击“2-输入ID抓取房源.cmd”。'
Write-Host '如果 Codex 正在运行，请完全退出并重新打开一次。'
Write-Host '为保护账号，建议复制一段普通文字，覆盖剪贴板中的 Key。'
Write-Line
exit 0
