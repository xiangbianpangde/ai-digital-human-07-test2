@echo off
chcp 65001 >nul
setlocal
set "PS_SCRIPT=%~dp0scripts\install.ps1"
if not exist "%PS_SCRIPT%" (
  echo Installation script is missing.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" echo Installation did not complete. See the message above.
pause
exit /b %EXIT_CODE%
