@echo off
chcp 65001 >nul
setlocal
set "PS_SCRIPT=%~dp0scripts\doctor.ps1"
if not exist "%PS_SCRIPT%" (
  echo Status script is missing.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
pause
exit /b %EXIT_CODE%
